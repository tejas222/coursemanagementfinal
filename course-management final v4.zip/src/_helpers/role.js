export const Role = {
    Admin: 'admin',
    Trainer: 'trainer'    
}