import React from 'react'
import "../styles/Footer.css";

function Footer() {
    return (
        <React.Fragment>
            <div className="footer">
                <p>Contact</p>
            </div>
        </React.Fragment>
    )
}

export default Footer
