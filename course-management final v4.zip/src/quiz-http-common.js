const baseUrl = "https://609e2a6333eed80017957dff.mockapi.io";

export default baseUrl;